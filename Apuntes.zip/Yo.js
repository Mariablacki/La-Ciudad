setTimeout(function() { 
    
    const pepa = document.querySelector(".pepa");
    document.body.classList.add('color')
    document.body.classList.add('active-background'); 
    document.documentElement.style.overflowY = 'auto';
    document.documentElement.style.overflowX = 'hidden';
    pepa.style.display = 'none';

}, 1000); 

